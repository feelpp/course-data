const crypto = require('node:crypto')
const path = require('node:path').posix

const asciidoctor = require('@asciidoctor/core')()
const JupyterConverter = require('asciidoctor-jupyter')
const extensionPackage = require('../package.json')
const converterPackage = require('asciidoctor-jupyter/package.json')

asciidoctor.ConverterFactory.register(JupyterConverter, ['jupyter'])

const DEFAULT_FIGURE_CONTRACT = 'alt text, caption, labelled axes and units, and non-colour encoding'
const PRIVATE_CELL_TAGS = new Set(['solution', 'instructor-only', 'remove-cell'])

function sha256 (value) {
  return crypto.createHash('sha256').update(value).digest('hex')
}

function parseHeaderAttributes (source) {
  const attributes = {}
  const lines = source.split(/\r?\n/)
  let titleSeen = false
  for (const line of lines) {
    if (!titleSeen) {
      if (line.startsWith('= ')) titleSeen = true
      continue
    }
    if (line === '' || line.startsWith('//')) continue
    const match = line.match(/^:([^:]+):(?:\s*(.*))?$/)
    if (!match) break
    attributes[match[1]] = match[2] || ''
  }
  return attributes
}

function listAttribute (attributes, name) {
  return (attributes[name] || '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean)
}

function mappedAttribute (attributes, name, parseValue) {
  const result = {}
  for (const item of (attributes[name] || '').split(';').map((value) => value.trim()).filter(Boolean)) {
    const separator = item.indexOf('=')
    if (separator < 1 || separator === item.length - 1) {
      throw new Error(`invalid ${name} entry: ${item}`)
    }
    const key = item.slice(0, separator).trim()
    if (Object.hasOwn(result, key)) throw new Error(`duplicate ${name} key: ${key}`)
    result[key] = parseValue(item.slice(separator + 1).trim(), key)
  }
  return result
}

function exerciseMetadata (page, attributes) {
  if (!attributes['page-course-exercise-id']) return undefined
  const required = [
    'page-course-assessment-id',
    'page-course-exercise-kind',
    'page-course-task-ids',
    'page-course-task-priorities',
    'page-course-task-points',
    'page-course-hint-policy',
    'page-course-ai-mode',
    'page-course-allowed-resources',
    'page-course-submission-evidence',
    'page-course-rubric-criteria'
  ]
  const missing = required.filter((name) => !attributes[name])
  if (missing.length) {
    throw new Error(`${resourceId(page.src)}: missing exercise metadata: ${missing.join(', ')}`)
  }
  const taskIds = listAttribute(attributes, 'page-course-task-ids')
  if (taskIds.length === 0 || new Set(taskIds).size !== taskIds.length) {
    throw new Error(`${resourceId(page.src)}: exercise task IDs must be non-empty and unique`)
  }
  const taskPriorities = mappedAttribute(
    attributes,
    'page-course-task-priorities',
    (value, key) => {
      const priorities = value.split('+').map((priority) => priority.trim()).filter(Boolean)
      if (
        priorities.length === 0 ||
        new Set(priorities).size !== priorities.length ||
        priorities.some((priority) => !['P0', 'P1', 'P2', 'P3'].includes(priority))
      ) {
        throw new Error(`invalid page-course-task-priorities value for ${key}: ${value}`)
      }
      return priorities
    }
  )
  const taskPoints = mappedAttribute(attributes, 'page-course-task-points', (value, key) => {
    const points = Number(value)
    if (!Number.isFinite(points) || points <= 0) {
      throw new Error(`invalid page-course-task-points value for ${key}: ${value}`)
    }
    return points
  })
  const declared = new Set(taskIds)
  for (const [name, mapping] of [
    ['page-course-task-priorities', taskPriorities],
    ['page-course-task-points', taskPoints]
  ]) {
    const mapped = new Set(Object.keys(mapping))
    if (mapped.size !== declared.size || [...declared].some((taskId) => !mapped.has(taskId))) {
      throw new Error(`${resourceId(page.src)}: ${name} keys must equal page-course-task-ids`)
    }
  }
  const aiMode = attributes['page-course-ai-mode']
  if (!['A', 'B', 'C'].includes(aiMode)) {
    throw new Error(`${resourceId(page.src)}: page-course-ai-mode must be A, B, or C`)
  }
  return {
    assessment_id: attributes['page-course-assessment-id'],
    exercise_id: attributes['page-course-exercise-id'],
    kind: attributes['page-course-exercise-kind'],
    task_ids: taskIds,
    task_priorities: taskPriorities,
    task_points: taskPoints,
    hint_policy: attributes['page-course-hint-policy'],
    ai_mode: aiMode,
    allowed_resources: listAttribute(attributes, 'page-course-allowed-resources'),
    submission_evidence: listAttribute(attributes, 'page-course-submission-evidence'),
    rubric_criteria: listAttribute(attributes, 'page-course-rubric-criteria')
  }
}

function resourceId ({ component, version, module, relative }, family = 'page') {
  const prefix = version ? `${version}@${component}` : component
  const familyMarker = family === 'page' ? '' : `${family}$`
  return `${prefix}:${module}:${familyMarker}${relative}`
}

function matchesInclude (relative, include) {
  if (!include || include.length === 0) return true
  return include.some((pattern) => {
    const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replaceAll('*', '.*')
    return new RegExp(`^${escaped}$`).test(relative)
  })
}

function isJupyterPage (page, options = {}) {
  const source = page.contents.toString('utf8')
  const attributes = parseHeaderAttributes(source)
  return Object.hasOwn(attributes, 'page-jupyter') && matchesInclude(page.src.relative, options.include)
}

function notebookMetadata (page, source, attributes, options) {
  const required = [
    'page-course-language',
    'page-course-priority',
    'page-course-difficulty',
    'page-course-duration-minutes',
    'page-course-concepts',
    'page-course-outcomes'
  ]
  const missing = required.filter((name) => !attributes[name])
  if (missing.length) {
    throw new Error(`${resourceId(page.src)}: missing notebook metadata: ${missing.join(', ')}`)
  }
  if (attributes['page-course-language'] !== 'en') {
    throw new Error(`${resourceId(page.src)}: generated notebooks must use English`)
  }
  const duration = Number.parseInt(attributes['page-course-duration-minutes'], 10)
  if (!Number.isInteger(duration) || duration < 1) {
    throw new Error(`${resourceId(page.src)}: invalid page-course-duration-minutes`)
  }
  const metadata = {
    schema_version: 1,
    source_kind: 'asciidoc',
    artifact_variant: 'student',
    solutions_included: false,
    source_resource_id: resourceId(page.src),
    source_path: page.src.relative,
    source_sha256: sha256(source),
    source_page_url: page.pub.url,
    language: 'en',
    priority: attributes['page-course-priority'],
    difficulty: attributes['page-course-difficulty'],
    duration_minutes: duration,
    concept_ids: listAttribute(attributes, 'page-course-concepts'),
    outcomes: listAttribute(attributes, 'page-course-outcomes'),
    execution_profile: attributes['page-course-execution-profile'] || 'fast',
    accessibility: {
      keyboard_only: true,
      colour_alone_forbidden: true,
      required_figure_contract: attributes['page-course-figure-contract'] || DEFAULT_FIGURE_CONTRACT
    },
    generator: {
      asciidoctor_jupyter: converterPackage.version,
      feelpp_antora_extensions: extensionPackage.version,
      feelpp_asciidoctor_extensions: options.asciidoctorExtensionVersion || '1.0.0-rc.17'
    }
  }
  const exercise = exerciseMetadata(page, attributes)
  if (exercise) metadata.exercise = exercise
  return metadata
}

function normaliseMarkdown (source, page) {
  return source
    .replace(
      /(^|\n)\+\n(\\[\s\S]*?)\n\+(?=\n|$)/g,
      (_match, prefix, latex) => `${prefix}$$\n${latex}\n$$`
    )
    .replace(/\]\(attachment\$([^)]+)\)/g, (_match, target) => {
      const relative = path.relative(path.dirname(page.src.relative), target)
      return `](${relative || path.basename(target)})`
    })
}

function normaliseCode (source, page) {
  return source.replace(/xref:attachment\$([^[]+)\[\]/g, (_match, target) => {
    const relative = path.relative(path.dirname(page.src.relative), target)
    return (relative || path.basename(target)).split(path.sep).join('/')
  })
}

function normaliseNotebook (notebook, page, source, attributes, options = {}) {
  notebook.nbformat = 4
  notebook.nbformat_minor = Math.max(notebook.nbformat_minor || 0, 5)
  notebook.metadata = notebook.metadata || {}
  notebook.metadata.kernelspec = notebook.metadata.kernelspec || {}
  notebook.metadata.kernelspec.name = notebook.metadata.kernelspec.name || 'python3'
  notebook.metadata.kernelspec.language = notebook.metadata.kernelspec.language || 'python'
  notebook.metadata.kernelspec.display_name = notebook.metadata.kernelspec.display_name || 'Python 3'
  notebook.metadata.course = notebookMetadata(page, source, attributes, options)
  const exercise = notebook.metadata.course.exercise
  const locatedTasks = new Set()
  notebook.cells.forEach((cell, index) => {
    let cellSource = Array.isArray(cell.source) ? cell.source.join('') : cell.source || ''
    if (cell.cell_type === 'markdown') {
      cellSource = normaliseMarkdown(cellSource, page)
      cell.source = cellSource
    }
    if (cell.cell_type === 'code') {
      cellSource = normaliseCode(cellSource, page)
      cell.source = cellSource
    }
    cell.metadata = cell.metadata || {}
    const cellTags = new Set(cell.metadata.tags || [])
    const privateTags = [...cellTags].filter((tag) => PRIVATE_CELL_TAGS.has(tag))
    if (privateTags.length) {
      throw new Error(`${resourceId(page.src)}: generated student cell contains private tags: ${privateTags.join(', ')}`)
    }
    if (exercise && cell.cell_type === 'markdown') {
      const taskIds = exercise.task_ids.filter((taskId) => cellSource.includes(taskId))
      if (taskIds.length) {
        taskIds.forEach((taskId) => locatedTasks.add(taskId))
        cellTags.add('exercise-prompt')
        cell.metadata.course = { task_ids: taskIds }
      }
    }
    if (cellTags.size) cell.metadata.tags = [...cellTags].sort()
    cell.id = sha256(`${resourceId(page.src)}\0${index}\0${cell.cell_type}\0${cellSource}`).slice(0, 16)
    if (cell.cell_type === 'code') {
      cell.execution_count = null
      cell.outputs = []
    }
  })
  if (exercise) {
    const missingTasks = exercise.task_ids.filter((taskId) => !locatedTasks.has(taskId))
    if (missingTasks.length) {
      throw new Error(`${resourceId(page.src)}: exercise tasks absent from notebook prompts: ${missingTasks.join(', ')}`)
    }
  }
  return notebook
}

function generateNotebook (page, options = {}) {
  const source = page.contents.toString('utf8')
  const attributes = parseHeaderAttributes(source)
  let notebook
  try {
    notebook = JSON.parse(asciidoctor.convert(source, {
      backend: 'jupyter',
      safe: 'safe',
      standalone: true,
      to_file: false,
      attributes: {
        'jupyter-language-name': attributes['jupyter-language-name'] || 'python',
        'jupyter-language-version': attributes['jupyter-language-version'] || '3.12',
        'jupyter-kernel-name': attributes['jupyter-kernel-name'] || 'python3',
        'jupyter-kernel-language': attributes['jupyter-kernel-language'] || 'python'
      }
    }))
  } catch (error) {
    throw new Error(`${resourceId(page.src)}: notebook conversion failed: ${error.message}`)
  }
  normaliseNotebook(notebook, page, source, attributes, options)
  return Buffer.from(`${JSON.stringify(notebook, null, 2)}\n`)
}

function attachmentRelative (page) {
  return page.src.relative.replace(/\.adoc$/, '.ipynb')
}

function manifestEntry (page, attachment, notebook) {
  const metadata = notebook.metadata.course
  const codeBlocks = notebook.cells
    .map((cell, index) => ({ cell, index }))
    .filter(({ cell }) => cell.cell_type === 'code')
    .map(({ cell, index }) => ({
      id: cell.id,
      index,
      source_sha256: sha256(Array.isArray(cell.source) ? cell.source.join('') : cell.source || ''),
      dynamic: false,
      required: true
    }))
  const entry = {
    source_resource_id: metadata.source_resource_id,
    source_path: metadata.source_path,
    source_sha256: metadata.source_sha256,
    page_url: page.pub.url,
    notebook_resource_id: resourceId(attachment.src, 'attachment'),
    notebook_path: attachment.src.relative,
    notebook_sha256: sha256(attachment.contents),
    notebook_url: attachment.pub.url,
    priority: metadata.priority,
    difficulty: metadata.difficulty,
    concept_ids: metadata.concept_ids,
    outcomes: metadata.outcomes,
    code_blocks: codeBlocks,
    warnings: []
  }
  if (metadata.exercise) entry.exercise = metadata.exercise
  return entry
}

function buildManifest (entries) {
  return Buffer.from(`${JSON.stringify({
    schema_version: 1,
    artifact: 'asciidoc-notebook-manifest',
    generator: {
      name: extensionPackage.name,
      version: extensionPackage.version
    },
    entries: [...entries].sort((a, b) => a.source_resource_id.localeCompare(b.source_resource_id))
  }, null, 2)}\n`)
}

function register (args = {}) {
  const logger = this.getLogger('jupyter-extension')
  const config = args.config || {}
  const options = args.jupyter || config.jupyter || config
  const generated = new Map()

  this.on('contentClassified', ({ contentCatalog }) => {
    const pages = contentCatalog.getPages().filter((page) => isJupyterPage(page, options))
      .sort((a, b) => resourceId(a.src).localeCompare(resourceId(b.src)))
    const entriesByComponent = new Map()
    for (const page of pages) {
      const contents = generateNotebook(page, options)
      const attachment = contentCatalog.addFile({
        contents,
        src: {
          component: page.src.component,
          version: page.src.version,
          module: page.src.module,
          family: 'attachment',
          relative: attachmentRelative(page)
        }
      })
      const notebook = JSON.parse(contents.toString('utf8'))
      const entry = manifestEntry(page, attachment, notebook)
      const key = `${page.src.component}\0${page.src.version || ''}`
      const group = entriesByComponent.get(key) || { page, entries: [] }
      group.entries.push(entry)
      entriesByComponent.set(key, group)
      generated.set(page, attachment)
      logger.info(`generated ${attachment.pub.url} from ${resourceId(page.src)}`)
    }
    for (const { page, entries } of entriesByComponent.values()) {
      contentCatalog.addFile({
        contents: buildManifest(entries),
        src: {
          component: page.src.component,
          version: page.src.version,
          module: 'ROOT',
          family: 'attachment',
          relative: 'generated/asciidoc-notebook-manifest.json'
        }
      })
    }
  })

  this.on('documentsConverted', () => {
    for (const [page, attachment] of generated) {
      page.asciidoc.attributes['page-jupyter-url'] = attachment.pub.url
      page.asciidoc.attributes['page-jupyter-status'] = 'generated'
    }
  })
}

module.exports = {
  attachmentRelative,
  buildManifest,
  generateNotebook,
  isJupyterPage,
  manifestEntry,
  mappedAttribute,
  normaliseMarkdown,
  normaliseCode,
  exerciseMetadata,
  parseHeaderAttributes,
  register,
  resourceId,
  sha256
}
